
#include <p18f4520.h>
#include <GenericTypeDefs.h>
//LATD7 PWR
//LATD6 EN
//LATD5 RW
//LATD4 RS

#define LCD_PWR     LATDbits.LATD7                ///< LCD ON/OFF line		
#define LCD_EN      LATDbits.LATD6               ///< LCD enable line
#define LCD_RW      LATDbits.LATD5                ///< LCD read/write line
#define LCD_RS      LATDbits.LATD4 				//reset
#define TRUE	1
#define FALSE	0

void WriteNibble(char Cmd, char Dat);
void WriteByte(char Cmd, char Dat);
void LCDClear(void);
void Wait(void);
void initialize(void);

volatile unsigned char sdata;

void Serial_ISR (void)
{
/******************************* SERIAL RECEPTION ***************************/

  if ((PIR1bits.RCIF) && (PIE1bits.RCIE))   // If a new character has been received
  {
    sdata = RCREG;                 		// Go store the new character in Rx buffer

  }   
	Nop();
	Nop();
	PIR1bits.TXIF = 0;
	TXREG = sdata;
	WriteByte(0, sdata);				// If new character has been received                                  

/***************************** SERIAL TRANSMISSION ****************************/

 /* if((PIR1bits.TXIF) && (PIE1bits.TXIE))    // If end of transmit
  {
    if (SERTxDatAvail())             // If data available for output
	{
      	SERSendNext();               // Go send next available character
	}
  } */
}


void main( void) {
	
	char data;

	TRISB = 0x00;
	PORTB = 0xFF;
	//while(1);

	initialize();
}
/*	while(1){
		TXREG = 0x42;
		while(!PIR1bits.RCIF);
		data = RCREG;
		PIR1bits.RCIF = 0;

		//WriteByte(FALSE, data);
	} */

void WriteNibble(char Cmd, char Dat)
{
	char buf;

	if(Cmd)		//command to be written
		LCD_RS = 0;	//set RS for instruction reg
	else
		LCD_RS = 1; // Otherwise we are writing data

	LCD_RW = 0;            // Set write mode
	LCD_EN = 1;            // Disable LCD

	LATDbits.LATD0 = LATDbits.LATD1 = LATDbits.LATD2 = LATDbits.LATD3= 0;    // Clear the data lines
	Nop();                                       			// Small delay
	Nop();

	buf =LATD;                   	// Getting the high nibble
	buf &= 0xF0;                  // Clear the low nibble
	LATD = buf | (Dat & 0x0F);   	// Combine & write back to the data lines
	Nop();                      	// Give the data a small delay to settle
	Nop();

	LCD_EN = 0; 	          // Enable LCD  -- active edge is when En transitions    
}

void WriteByte(char Cmd, char Dat)
{
	WriteNibble(Cmd, Dat >> 4);            // Output the high nibble to the LCD
	WriteNibble(Cmd, Dat);                 // Now send the low nibble
}

void LCDClear(void)
{
  WriteByte(TRUE,0x01);                       // Send clear display command
  Wait();                                  // Wait until command is finished
}

void Wait(void) //delay for LCD write
{
	char i, j;

/*	for (i = 0; i < 5; i++)
		for (j = 0; j < 5; j++)
			Nop();*/
	for (i = 0; i<255; i++)
			Nop();
		
}								  // from high to low?

void initialize (void){

	//CONFIG1Hbits.FOSC0 = 1;
	//CONFIG1Hbits.FOSC3=CONFIG1Hbits.FOSC2=CONFIG1Hbits.FOSC1 = 0;

	OSCCONbits.IDLEN = 1;
	OSCCONbits.SCS1 = 0;
	OSCCONbits.SCS0 = 0;


	// Reset USART registers to POR state
	TXSTA = 0;          
	RCSTA = 0;
  
  	// Continuous or single reception
	SPBRG = 25;       // Write baudrate to SPBRG
						//fosc/[16(n+1)] -- 12 = 19200 baud

	TXSTAbits.SYNC = 0;	// Sync or async operation
	RCSTAbits.SPEN = 1;  // Enable receiver
	TXSTAbits.TXEN = 1;  // Enable transmitter
	RCSTAbits.CREN = 1; //enables rx

	BAUDCONbits.BRG16 = 0; //8 bit BRG reg
	TXSTAbits.BRGH = 1; //baud rate generator speed

//	RCONbits.IPEN = 0; //disable all priority levels
	INTCONbits.GIE = 1; //Global interrupt enable
	INTCONbits.PEIE = 1; //Peripheral interrupt enable

	PIE1bits.RCIE = 1; //interrupt on receive enable (0 - disabled)
	PIE1bits.TXIE = 1;// Interrupt on transmission (0 - disabled)

	//(0) 8- or (1) 9-bit mode
	TXSTAbits.TX9 = 0;	
	RCSTAbits.RX9 = 0;

//	PIR1bits.RCIF = 0;

	TRISCbits.RC6 = 0; //sets Tx to output
	TRISCbits.RC7 = 1; //sets Rx to input

	TRISD = 0;
	LATD = 0;

	LCD_PWR = 1; //turn LCD on
	LCD_RS = 0;  //Set to command
	LCD_RW = 0;  //set write
	LCD_EN = 1;  //set high
	LCD_RS = 0;  //goes low (active edge)

	Wait();
	WriteByte(1, 0b00100000);//set 4 bit mode
	Wait();
	WriteByte(1, 0b00100000);//function set
	Wait();
	WriteByte(1, 0b00001110);//display on
	Wait();
	WriteByte(1, 0b00000110);//cursor and right shift
	Wait();
}