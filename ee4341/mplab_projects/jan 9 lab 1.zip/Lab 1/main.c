
#include <p18f4520.h>
#include <GenericTypeDefs.h>
//LATD7 PWR
//LATD6 EN
//LATD5 RW
//LATD4 RS

#define LCD_PWR     LATDbits.LATD7                ///< LCD ON/OFF line		
#define LCD_EN      LATDbits.LATD6               ///< LCD enable line
#define LCD_RW      LATDbits.LATD5                ///< LCD read/write line
#define LCD_RS      LATDbits.LATD4 				//reset

void WriteNibble(char Cmd, char Dat);
void WriteByte(char Cmd, char Dat);
void LCDClear(void);
void Wait(int i);
void initialize(void);

volatile unsigned char sdata;

#pragma interruptlow low_priority_interrupt 

void low_priority_interrupt(void)
{
/******************************* SERIAL RECEPTION ***************************/

  if (PIR1bits.RCIF){   // If a new character has been received
    sdata = RCREG;                 		// Go store the new character in Rx buffer
  } 
	Nop();
	Nop();
	WriteByte(0, sdata);
	TXREG = sdata;
}


void main( void) {
	
	char data;

	TRISB = 0x00;
	PORTB = 0xFF;
	
	initialize();
	while(1){
	}
}

void WriteNibble(char Cmd, char Dat)
{
	char buf;

	if(Cmd)		//command to be written
		LCD_RS = 0;	//set RS for instruction reg
	else
		LCD_RS = 1; // Otherwise we are writing data

	LCD_EN = 0;
	LCD_RW = 0;            // Set write mode

	buf =LATD;                  	// Getting the high nibble
	buf &= 0xF0;                  // Clear the low nibble
	LATD = buf | (Dat & 0x0F);   	// Combine & write back to the data lines  

	Delay10TCYx(1);
	LCD_EN = 1;
	Delay10TCYx(1);	
	LCD_EN = 0;
}

void WriteByte(char Cmd, char Dat)
{
	WriteNibble(Cmd, Dat >> 4);            // Output the high nibble to the LCD
	Delay1KTCYx(2);
	WriteNibble(Cmd, Dat);                 // Now send the low nibble
}


void Wait(int i) //delay for LCD write
{
	int j; 
	for( j=0; j<i; j++)
		Nop();
		
}								  // from high to low?

void initialize (void){
	
	TRISD = 0;
	LATD = 0;

	Delay10KTCYx(20);   // 

	LCD_PWR = 1; //turn LCD on

	Delay100TCYx(5);
	WriteNibble(1, 0b00000010);    
	Delay100TCYx(1);
	WriteNibble(1, 0x00000000);    
	Delay100TCYx(10);
	WriteNibble(1, 0b00000010);    
//	Delay100TCYx(1);
	WriteNibble(1, 0b00000000);    
	Delay100TCYx(10);
	WriteNibble(1, 0b00000000);    
//	Delay100TCYx(1);
	WriteNibble(1, 0b00001110);    
	Delay100TCYx(10);
	WriteNibble(1, 0b00000000);    
//	Delay100TCYx(1);
	WriteNibble(1, 0b00000110);    
	Delay100TCYx(5);

	/*
	WriteByte(1, 0x02);//set 4 bit mode
	Wait(100);
	WriteByte(1, 0x28);//function set
	Wait(100);
	WriteByte(1, 0x0E);//display on
	Wait(100);
	WriteByte(1, 0x06);//cursor and right shift
	Wait(100);
	//WriteByte(0, 0b01001000);//cursor and right shift
	//Wait(100);*/

	while(1);
	PORTB = 0b1010101010;

	//CONFIG1Hbits.FOSC0 = 1;
	//CONFIG1Hbits.FOSC3=CONFIG1Hbits.FOSC2=CONFIG1Hbits.FOSC1 = 0;

	OSCCONbits.IDLEN = 1;
	OSCCONbits.SCS1 = 0;
	OSCCONbits.SCS0 = 0;


	// Reset USART registers to POR state
	TXSTA = 0;          
	RCSTA = 0;
  
  	// Continuous or single reception
	SPBRG = 12;       // Write baudrate to SPBRG
						//fosc/[16(n+1)] -- 12 = 19200 baud

	TXSTAbits.SYNC = 0;	// Sync or async operation
	RCSTAbits.SPEN = 1;  // Enable receiver
	TXSTAbits.TXEN = 1;  // Enable transmitter
	RCSTAbits.CREN = 1; //enables rx

	BAUDCONbits.BRG16 = 0; //8 bit BRG reg
	TXSTAbits.BRGH = 1; //baud rate generator speed

//	RCONbits.IPEN = 0; //disable all priority levels
	INTCONbits.GIE = 1; //Global interrupt enable
	INTCONbits.PEIE = 1; //Peripheral interrupt enable

	PIE1bits.RCIE = 1; //interrupt on receive enable (0 - disabled)
	PIE1bits.TXIE = 0;// Interrupt on transmission (0 - disabled)

	//(0) 8- or (1) 9-bit mode
	TXSTAbits.TX9 = 0;	
	RCSTAbits.RX9 = 0;

//	PIR1bits.RCIF = 0;

	TRISCbits.RC6 = 0; //sets Tx to output
	TRISCbits.RC7 = 1; //sets Rx to input




}