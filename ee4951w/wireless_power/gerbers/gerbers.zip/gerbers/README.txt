Board Dimensions: 2927.01 x 6299.21 mils

Board is two layers

All files are formated as RS274X 2.4 trailing or EXCELLON 2.4 trailing format

Board outline is shown in top copper layer.

Files:
-"wpt.GTL" top copper layer
-"wpt.GBL" bottom copper layer
-"wpt.GTO" top silkscreen
-"wpt.GBO" bottom silkscreen
-"wpt.GTS" top soldermask
-"wpt.GBS" bottom soldermask
-"wpt.TXT" NC drill file


